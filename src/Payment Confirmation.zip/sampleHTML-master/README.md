# Sample HTML
This repo contains all the files necessary to open a simple HTML-based website. It was created for the purpose of being used by Academy Cadets in their final project.

## Prerequisites
There are no prerequisites for this project.

## Download and Usage
To view, use, or edit the HTML code, clone the repo onto your local machine wherever you want it. <br>
From there, you should be able to copy the file path to `academy_html.html` and paste it into a browser tab to see the website. 

## Troubleshooting
Make sure that all images and `.html`, `.jpg`, and `.css` files are in the same directory.